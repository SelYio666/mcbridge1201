# 分享用：Minecraft 下载源速查

这个文件夹是**独立可分享**的，不依赖 GitHub、不需要安装任何东西。

## 三个文件

| 文件 | 用途 |
|---|---|
| `index.html` | 自包含网页，双击用浏览器打开；可直接发给别人（QQ/微信/网盘） |
| `sources.md` | 纯文本版，适合贴群公告/论坛/文档 |
| `README.md` | 本说明 |

页面无外部依赖（CSS 全内联），离线可用；虽然含链接，但断网也能阅读。

## 怎么发给“不访问 GitHub 的人”

1. **直接发文件**：把 `index.html` 发过去，对方双击即看。最省事。
2. **免费静态托管**（有公网链接、对方只需点开）：
   - Cloudflare Pages：新建项目 → Direct Upload → 上传本文件夹 → 得到 `*.pages.dev` 地址；
   - Netlify Drop：拖拽本文件夹到 app.netlify.com/drop；
   - Gitee Pages：建公开仓库上传本文件夹后开启 Pages（国内访问较稳）。
3. **放到自己的网站上**：把 `index.html` 改名为任意路径下的 `index.html` 即可。

> 本页只列公开地址，不含游戏/模组文件，托管不涉及侵权分发；但仍请遵守 Mojang EULA 与各镜像条款。

## 更新

源地址变更时改 `index.html`（表格 + 实测状态表）与 `sources.md` 两处即可；日期记得同步。
