package probe;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.*;
import com.misterpemodder.shulkerboxtooltip.api.*;
public class ShulkerContractProbe implements ClientModInitializer {
 int ticks=0;
 public void onInitializeClient() {
  ClientTickEvents.END_CLIENT_TICK.register(c -> {
   if (++ticks != 80) return;
   try {
    var item=class_7923.field_41178.method_10223(class_2960.method_60655("minecraft","shulker_box"));
    var diamond=class_7923.field_41178.method_10223(class_2960.method_60655("minecraft","diamond"));
    var stack=new class_1799(item);
    var contents=java.util.List.of(new class_1799(diamond,5));
    stack.method_57379(class_9334.field_49622,class_9288.method_57493(contents));
    int nativeCount=0;for(var value:stack.method_57824(class_9334.field_49622).method_59714()) nativeCount+=value.method_7947();
    System.out.println("SHULKER_FIXTURE nativeContainerCount=" + nativeCount);
    com.misterpemodder.shulkerboxtooltip.impl.PluginManager.loadProviders();
    var context=PreviewContext.of(stack);
    var provider=ShulkerBoxTooltipApi.getPreviewProviderForStack(stack);
    System.out.println("SHULKER_PROVIDER class=" + (provider==null?"null":provider.getClass().getName()));
    if (provider == null) { System.out.println("SHULKER_CONTRACT_FAIL noProvider");return; }
    var inv=provider.getInventory(context);
    int count=inv.stream().filter(s -> s.method_31574(diamond)).mapToInt(class_1799::method_7947).sum();
    System.out.println("SHULKER_CONTRACT_RESULT diamondCount="+count+" expected=5 shouldDisplay="+provider.shouldDisplay(context));
   } catch (Throwable e) {System.out.println("SHULKER_CONTRACT_FAIL "+e);e.printStackTrace();}
  });
 }
}