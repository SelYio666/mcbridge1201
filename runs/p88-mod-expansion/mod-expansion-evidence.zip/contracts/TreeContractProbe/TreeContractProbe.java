package probe;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.*;
public class TreeContractProbe implements ModInitializer {
 class_3222 player;int ticks=0;boolean failed=false;
 public void onInitialize() {
  ServerPlayConnectionEvents.JOIN.register((h,s,v) -> {player=h.method_32311();System.out.println("TREE_PLAYER_JOINED");});
  ServerTickEvents.END_SERVER_TICK.register(server -> {
   if(player==null||failed)return;
   ticks++;var w=player.method_51469();
   try {
    if(ticks==40){
     var stone=class_7923.field_41175.method_10223(class_2960.method_60655("minecraft","stone")).method_9564();
     var air=class_7923.field_41175.method_10223(class_2960.method_60655("minecraft","air")).method_9564();
     var log=class_7923.field_41175.method_10223(class_2960.method_60655("minecraft","oak_log")).method_9564();
     var leaves=class_7923.field_41175.method_10223(class_2960.method_60655("minecraft","oak_leaves")).method_9564();
     for(int x=28;x<=36;x++)for(int z=28;z<=36;z++){
      w.method_8652(new class_2338(x,109,z),stone,3);
      for(int y=110;y<=116;y++)w.method_8652(new class_2338(x,y,z),air,3);
     }
     for(int x=31;x<=33;x++)for(int z=31;z<=33;z++)w.method_8652(new class_2338(x,114,z),leaves,3);
     for(int y=110;y<=113;y++)w.method_8652(new class_2338(32,y,32),log,3);
     player.method_7336(class_1934.field_9215);
     player.method_5814(30,110,32);
     var axe=class_7923.field_41178.method_10223(class_2960.method_60655("minecraft","diamond_axe"));
     player.method_6122(class_1268.field_5808,new class_1799(axe));
     System.out.println("TREE_FIXTURE logs=4 axe="+player.method_6047());
    }
    if(ticks==60){
     boolean broke=player.field_13974.method_14266(new class_2338(32,110,32));
     System.out.println("TREE_BREAK_RESULT broke="+broke);
    }
    if(ticks==100){
     int logs=0;
     for(int y=110;y<=113;y++)if(w.method_8320(new class_2338(32,y,32)).toString().contains("oak_log"))logs++;
     System.out.println("TREE_CONTRACT_RESULT remainingLogs="+logs+" expected=0");
    }
   }catch(Throwable e){failed=true;System.out.println("TREE_CONTRACT_FAIL "+e);e.printStackTrace();}
  });
 }
}