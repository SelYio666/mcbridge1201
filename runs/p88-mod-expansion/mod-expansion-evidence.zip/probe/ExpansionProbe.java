package probe;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
public class ExpansionProbe implements ClientModInitializer {
 int ticks=0;
 public void onInitializeClient() {
  ClientLifecycleEvents.CLIENT_STARTED.register(c -> System.out.println("EXPANSION_CLIENT_STARTED"));
  ClientTickEvents.END_CLIENT_TICK.register(c -> {
   if (++ticks == 120) System.out.println("EXPANSION_CLIENT_120_TICKS screen=" + (c.field_1755 == null ? "null" : c.field_1755.getClass().getName()));
  });
 }
}