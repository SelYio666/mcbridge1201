from pathlib import Path
import subprocess, json, os, time, shutil, re, uuid, sys, zipfile
B=Path(__file__).resolve().parent; R=B/'expansion'; T=B/'test-repo/work/target'
J=B/'jdk21/bin'; TEMPLATE=B/'test-repo/work/instances/fabric-1.21.1-server'
MC=Path('D:/我的世界/.minecraft')
SAMPLES=json.loads((R/'patch-results.json').read_text())

def probe():
    d=R/'probe';d.mkdir(exist_ok=True)
    src=d/'ExpansionProbe.java'
    src.write_text('''package probe;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
public class ExpansionProbe implements ClientModInitializer {
 int ticks=0;
 public void onInitializeClient() {
  ClientLifecycleEvents.CLIENT_STARTED.register(c -> System.out.println("EXPANSION_CLIENT_STARTED"));
  ClientTickEvents.END_CLIENT_TICK.register(c -> {
   if (++ticks == 120) System.out.println("EXPANSION_CLIENT_120_TICKS screen=" + (c.field_1755 == null ? "null" : c.field_1755.getClass().getName()));
  });
 }
}''',encoding='utf-8')
    cp=[B/'test-repo/work/cb/data/jars/client-1.21.1-intermediary.jar',T/'fabric-loader-0.19.5.jar',* (B/'probes/deps').glob('*.jar')]
    p=subprocess.run([str(J/'javac.exe'),'-encoding','UTF-8','-proc:none','--release','21','-cp',';'.join(map(str,cp)),'-d',str(d),str(src)],capture_output=True,text=True)
    (d/'compile.log').write_text(p.stdout+p.stderr)
    if p.returncode:raise RuntimeError(p.stderr)
    with zipfile.ZipFile(d/'expansionprobe.jar','w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('fabric.mod.json',json.dumps({'schemaVersion':1,'id':'expansionprobe','version':'1.0','environment':'client','entrypoints':{'client':['probe.ExpansionProbe']}}))
        for f in d.rglob('*.class'):z.write(f,f.relative_to(d).as_posix())

def allowed(lib):
    rules=lib.get('rules')
    if not rules:return True
    yes=False
    for rule in rules:
        if rule.get('os',{}).get('name') in (None,'windows'):yes=rule['action']=='allow'
    return yes

def client_args(game):
    vanilla=json.loads((MC/'versions/1.21.1/1.21.1.json').read_text())
    fabric=json.loads((MC/'versions/fabric-loader-0.19.5-1.21.1/fabric-loader-0.19.5-1.21.1.json').read_text())
    cp=[]
    for lib in vanilla['libraries']:
        if allowed(lib):
            path=lib.get('downloads',{}).get('artifact',{}).get('path')
            if path:cp.append(MC/'libraries'/path)
    for lib in fabric['libraries']:
        group,artifact,version=lib['name'].split(':')[:3]
        cp.append(MC/'libraries'/group.replace('.','/')/artifact/version/f'{artifact}-{version}.jar')
    cp.append(MC/'versions/1.21.1/1.21.1.jar')
    for f in cp:
        if not f.exists():raise FileNotFoundError(f)
    return [str(J/'java.exe'),'-Xmx1536M','-Xms256M',f'-Djava.io.tmpdir={game/"tmp"}','-Dfile.encoding=UTF-8',
            '-cp',';'.join(map(str,cp)),fabric['mainClass'],'--username','ExpandTest','--version','1.21.1',
            '--gameDir',str(game),'--assetsDir',str(MC/'assets'),'--assetIndex','17','--uuid',
            str(uuid.uuid3(uuid.NAMESPACE_DNS,'OfflinePlayer:ExpandTest')).replace('-',''),'--accessToken','0',
            '--clientId','0','--xuid','0','--versionType','release','--width','854','--height','480']

def read(path):return path.read_text(encoding='utf-8',errors='replace') if path.exists() else ''
def wait_until(test,seconds):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        if test():return True
        time.sleep(.25)
    return False

def run(s,side,variant='patched',extra=None):
    game=R/'runtime'/f'{s["slug"]}-{side}-{variant}'
    game.mkdir(parents=True,exist_ok=True)
    mods=game/'mods';mods.mkdir(exist_ok=True);(game/'tmp').mkdir(exist_ok=True)
    shutil.copy2(T/'fabric-api-0.102.0+1.21.1.jar',mods/'fabric-api.jar')
    jar=s['patchedFile'] if variant!='converted' else s['convertedFiles'][0]
    if s['slug']!='control':shutil.copy2(jar,mods/Path(jar).name)
    if extra:shutil.copy2(extra,mods/Path(extra).name)
    if side=='server':
        for folder in ['libraries','versions','.fabric']:
            if not (game/folder).exists():shutil.copytree(TEMPLATE/folder,game/folder)
        for name in ['fabric-server-launch.jar','eula.txt']:shutil.copy2(TEMPLATE/name,game/name)
        (game/'server.properties').write_text('online-mode=false\nserver-ip=127.0.0.1\nserver-port=25671\nlevel-name=world\nlevel-seed=42\nview-distance=2\nsimulation-distance=2\nspawn-protection=0\nmax-players=2\n',encoding='utf-8')
        args=[str(J/'java.exe'),'-Xmx1536M','-Dfile.encoding=UTF-8',f'-Djava.io.tmpdir={game/"tmp"}','-jar','fabric-server-launch.jar','nogui']
    else:
        shutil.copy2(R/'probe/expansionprobe.jar',mods/'expansionprobe.jar')
        (game/'options.txt').write_text('renderDistance:2\nsimulationDistance:2\nmaxFps:30\npauseOnLostFocus:false\nlang:en_us\nsoundCategory_master:0.0\ngraphicsMode:0\nguiScale:2\nenableVsync:false\n',encoding='utf-8')
        args=client_args(game)
    (game/'launch.json').write_text(json.dumps(args,indent=2),encoding='utf-8')
    start=time.monotonic();log=game/'console.log';commands=[]
    with log.open('w',encoding='utf-8') as f:
        p=subprocess.Popen(args,cwd=game,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.PIPE,text=True,encoding='utf-8',creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            marker='Done (' if side=='server' else 'EXPANSION_CLIENT_120_TICKS'
            observed=wait_until(lambda:marker in read(log) or p.poll() is not None,150)
            boot=marker in read(log) and p.poll() is None
            state={'slug':s['slug'],'side':side,'variant':variant,'marker':marker,'markerSeen':marker in read(log),
                   'aliveBeforeCleanup':p.poll() is None,'exitBeforeCleanup':p.poll(),'timeout':not observed,'seconds':round(time.monotonic()-start,2),'jar':jar}
            def cmd(c):
                commands.append(c);p.stdin.write(c+'\n');p.stdin.flush()
            if boot and side=='server':
                cmd('gamerule doMobSpawning false');cmd('forceload add 0 0');cmd('tick freeze')
                cmd('kill @e[type=minecraft:experience_orb]')
                for value in [3,7]:cmd('summon minecraft:experience_orb 0 100 0 {Value:'+str(value)+'s,NoGravity:1b,Motion:[0.0d,0.0d,0.0d],Tags:["expansion"]}')
                cmd('tick step 200t');time.sleep(12)
                cmd('execute as @e[type=minecraft:experience_orb,tag=expansion] run data get entity @s Value')
                time.sleep(2)
                state['xpValues']=re.findall(r'Experience Orb has the following entity data: (\d+)s',read(log))
                state['aliveAfterXp']=p.poll() is None
                cmd('say EXPANSION_WORLD_COMMANDS_DONE');time.sleep(1)
        finally:
            if p.poll() is None:
                if side=='server':
                    try:p.stdin.write('stop\n');p.stdin.flush();p.wait(timeout=35)
                    except Exception:p.kill()
                else:p.terminate()
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:p.kill();p.wait()
    state['exitAfterCleanup']=p.returncode;state['cleanup']='graceful-stop' if side=='server' and boot else 'terminate-client' if side=='client' and boot else 'none-or-timeout'
    (game/'commands.txt').write_text('\n'.join(commands),encoding='utf-8')
    state['logs']=str(game.relative_to(R))
    (game/'verdict.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
    print(json.dumps(state),flush=True)
    return state

if __name__=='__main__':
    probe()
    mode=sys.argv[1] if len(sys.argv)>1 else 'server'
    if mode=='server':
        cases=[(s,'server') for s in SAMPLES if s['slug'] in ['clumps','fallingtree','ferrite-core']]
        cases.insert(0,({'slug':'control','patchedFile':'none'},'server'))
    else:cases=[(s,'client') for s in SAMPLES]
    out=[]
    for s,side in cases:
        out.append(run(s,side))
        (R/f'{mode}-results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
