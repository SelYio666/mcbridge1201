from pathlib import Path
import shutil, subprocess, json, os, time

BASE=Path(__file__).resolve().parent
ROOT=BASE/'expansion'
REPO=BASE/'expansion-repo'
OLD=Path(r'C:\Users\27682\Documents\新建文件夹\mcbridge1201')
ENGINE=OLD/'work/upstream/src/CenturyBridge-cf4ebeba2eaaa49d3746162cc2c10b670d681aec'
JAVA=BASE/'jdk21/bin'
TMP=ROOT/'tmp';TMP.mkdir(parents=True,exist_ok=True)
CB=ROOT/'cb'
(CB/'data/jars').mkdir(parents=True,exist_ok=True)
for name in ['client-1.20.1-intermediary.jar','client-1.21.1-intermediary.jar']:
    shutil.copy2(OLD/'work/cb/data/jars'/name,CB/'data/jars'/name)
shutil.copytree(OLD/'work/cb/data/segments',CB/'data/segments',dirs_exist_ok=True)
shutil.copytree(OLD/'work/cb/data/mappings',CB/'data/mappings',dirs_exist_ok=True)
classes=ROOT/'engine-classes';classes.mkdir(exist_ok=True)
libs=list((OLD/'work/lib').glob('asm*.jar'))+[OLD/'work/lib/gson-2.11.0.jar']
cp=';'.join(map(str,libs))
sources=list((ENGINE/'core/src').rglob('*.java'))+[REPO/'patches/centurybridge/MixinCheck.java']
with (ROOT/'engine-build.log').open('w',encoding='utf-8') as log:
    r=subprocess.run([str(JAVA/'javac.exe'),'-encoding','UTF-8','-cp',cp,'-d',str(classes),*map(str,sources)],
                     stdout=log,stderr=subprocess.STDOUT)
    if r.returncode:raise RuntimeError('engine compilation failed')
samples=json.loads((ROOT/'samples.json').read_text(encoding='utf-8'))
for sample in samples:
    if sample['status']!='downloaded':continue
    slug=sample['slug']
    out=ROOT/'converted'/slug
    out.mkdir(parents=True,exist_ok=True)
    cmd=[str(JAVA/'java.exe'),'-Xmx1536M','-Dfile.encoding=UTF-8',f'-Djava.io.tmpdir={TMP}',
         '-cp',str(classes)+';'+cp,'top.dext.centurybridge.Main','convert',str(CB/'data/segments'),
         '1.20.1','1.21.1',str(out),sample['path']]
    t=time.monotonic()
    with (out/'convert.log').open('w',encoding='utf-8') as log:
        r=subprocess.run(cmd,cwd=CB,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    sample['conversionExitCode']=r.returncode
    sample['conversionSeconds']=round(time.monotonic()-t,2)
    sample['convertedFiles']=[str(p) for p in out.glob('*.jar')]
    print(slug,'conversion exit',r.returncode,'jars',len(sample['convertedFiles']),flush=True)
    (ROOT/'conversion-results.json').write_text(json.dumps(samples,indent=2),encoding='utf-8')
