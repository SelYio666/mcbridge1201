from pathlib import Path
import urllib.request,urllib.parse,json,hashlib
R=Path(__file__).resolve().parent/'expansion';out=R/'dependencies';out.mkdir(exist_ok=True)
def get(url):
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'mcbridge-independent-test/0.2'}),timeout=35) as f:return f.read()
records=[]
for slug in ['cloth-config','clumps']:
    query=urllib.parse.urlencode({'loaders':json.dumps(['fabric']),'game_versions':json.dumps(['1.21.1'])})
    versions=json.loads(get('https://api.modrinth.com/v2/project/'+slug+'/version?'+query))
    v=next(x for x in versions if x['version_type']=='release')
    file=next((f for f in v['files'] if f.get('primary')),v['files'][0])
    data=get(file['url']);assert hashlib.sha512(data).hexdigest()==file['hashes']['sha512']
    path=out/file['filename'];path.write_bytes(data)
    records.append({'slug':slug,'version':v['version_number'],'versionId':v['id'],'path':str(path),'file':file,'sha512Verified':True})
    print(slug,v['version_number'],flush=True)
(R/'dependencies.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
