from expand_runtime import R,B,J,T,TEMPLATE,SAMPLES,client_args,read,wait_until
import shutil,subprocess,json,time,os
root=R/'runtime/fallingtree-tree-contract';server=root/'server';client=root/'client'
for d in [server,client]:
    (d/'mods').mkdir(parents=True,exist_ok=True);(d/'tmp').mkdir(exist_ok=True)
for folder in ['libraries','versions','.fabric']:
    if not (server/folder).exists():shutil.copytree(TEMPLATE/folder,server/folder)
for name in ['fabric-server-launch.jar','eula.txt']:shutil.copy2(TEMPLATE/name,server/name)
for game in [server,client]:shutil.copy2(T/'fabric-api-0.102.0+1.21.1.jar',game/'mods/fabric-api.jar')
shutil.copy2(next(s['patchedFile'] for s in SAMPLES if s['slug']=='fallingtree'),server/'mods/fallingtree.jar')
shutil.copy2(R/'contracts/TreeContractProbe.jar',server/'mods/treecontract.jar')
(server/'server.properties').write_text('online-mode=false\nserver-ip=127.0.0.1\nserver-port=25672\nlevel-name=world\nlevel-seed=42\nview-distance=2\nsimulation-distance=2\nspawn-protection=0\n',encoding='utf-8')
(client/'options.txt').write_text('renderDistance:2\nsimulationDistance:5\nmaxFps:30\npauseOnLostFocus:false\nsoundCategory_master:0.0\ngraphicsMode:0\nenableVsync:false\n',encoding='utf-8')
handles=[];procs=[];result={}
def spawn(args,game):
    (game/'launch.json').write_text(json.dumps(args,indent=2),encoding='utf-8')
    f=(game/'console.log').open('w',encoding='utf-8');handles.append(f)
    p=subprocess.Popen(args,cwd=game,stdin=subprocess.PIPE,stdout=f,stderr=subprocess.STDOUT,text=True,encoding='utf-8',creationflags=subprocess.CREATE_NO_WINDOW);procs.append(p);return p
try:
    s=spawn([str(J/'java.exe'),'-Xmx1536M',f'-Djava.io.tmpdir={server/"tmp"}','-Dfile.encoding=UTF-8','-jar','fabric-server-launch.jar','nogui'],server)
    wait_until(lambda:s.poll() is not None or 'Done (' in read(server/'console.log'),100)
    if s.poll() is not None:raise RuntimeError('server failed')
    c=spawn(client_args(client)+['--quickPlayMultiplayer','127.0.0.1:25672'],client)
    wait_until(lambda:s.poll() is not None or c.poll() is not None or any(x in read(server/'console.log') for x in ['TREE_CONTRACT_RESULT','TREE_CONTRACT_FAIL']),120)
    time.sleep(2)
    result={'serverAlive':s.poll() is None,'clientAlive':c.poll() is None,'serverExitBeforeCleanup':s.poll(),'clientExitBeforeCleanup':c.poll(),
            'markers':[line for line in read(server/'console.log').splitlines() if 'TREE_' in line]}
finally:
    for p in procs[1:]:
        if p.poll() is None:p.terminate()
    if procs and procs[0].poll() is None:
        try:procs[0].stdin.write('stop\n');procs[0].stdin.flush();procs[0].wait(timeout=35)
        except Exception:procs[0].kill()
    for p in procs:
        try:p.wait(timeout=10)
        except subprocess.TimeoutExpired:p.kill();p.wait()
    for f in handles:f.close()
    result['exitAfterCleanup']=[p.returncode for p in procs]
    (root/'verdict.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
