from pathlib import Path
import urllib.request, urllib.parse, json, hashlib, concurrent.futures, shutil, time

BASE=Path(__file__).resolve().parent
OUT=BASE/'expansion'
OUT.mkdir(exist_ok=True)
REPO=BASE/'expansion-repo'
CACHED=BASE/'test-repo/work/corpus'

def get(url):
    error=None
    for _ in range(3):
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'mcbridge-independent-test/0.2'})
            with urllib.request.urlopen(req,timeout=25) as r:return r.read()
        except Exception as e:error=e
    raise error

def api(route):return json.loads(get('https://api.modrinth.com/v2/'+route))

def fetch(slug):
    path=OUT/'metadata'/f'{slug}.json'
    path.parent.mkdir(exist_ok=True)
    try:
        project=api('project/'+slug)
        query=urllib.parse.urlencode({'loaders':json.dumps(['fabric']),'game_versions':json.dumps(['1.20.1'])})
        versions=api('project/'+slug+'/version?'+query)
        versions=[v for v in versions if '1.21.1' not in v['game_versions']]
        if slug in ['appleskin','modmenu']:
            version_id={'appleskin':'N5XeV21r','modmenu':'lEkperf6'}[slug]
            version=api('version/'+version_id)
        else:
            version=next((v for v in versions if v['version_type']=='release'),versions[0])
        file=next((f for f in version['files'] if f.get('primary')),version['files'][0])
        dest=OUT/'raw'/file['filename']
        dest.parent.mkdir(exist_ok=True)
        cached=CACHED/slug/file['filename']
        if dest.exists():data=dest.read_bytes()
        elif cached.exists():data=cached.read_bytes()
        else:data=get(file['url'])
        assert hashlib.sha512(data).hexdigest()==file['hashes']['sha512']
        dest.write_bytes(data)
        result={'slug':slug,'title':project['title'],'versionId':version['id'],
            'version':version['version_number'],'file':file,'path':str(dest),
            'sha256':hashlib.sha256(data).hexdigest(),'sha512Verified':True,
            'license':project.get('license'),'gameVersions':version['game_versions'],
            'dependencies':version['dependencies'],'status':'downloaded'}
        path.write_text(json.dumps(result,indent=2),encoding='utf-8')
        return result
    except Exception as e:
        result={'slug':slug,'status':'fetch_failed','error':str(e)}
        path.write_text(json.dumps(result,indent=2),encoding='utf-8')
        return result

slugs=['appleskin','modmenu','clumps','fallingtree','ferrite-core','shulkerboxtooltip']
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results=list(pool.map(fetch,slugs))
(OUT/'samples.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
for r in results:print(r['slug'],r.get('version'),r['status'],r.get('error',''))
