from pathlib import Path
import subprocess,json,zipfile
from expand_runtime import R,B,J,T
D=R/'contracts';D.mkdir(exist_ok=True)
sources={
'ShulkerContractProbe':'''package probe;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.*;
import com.misterpemodder.shulkerboxtooltip.api.*;
public class ShulkerContractProbe implements ClientModInitializer {
 int ticks=0;
 public void onInitializeClient() {
  ClientTickEvents.END_CLIENT_TICK.register(c -> {
   if (++ticks != 80) return;
   try {
    var item=class_7923.field_41178.method_10223(class_2960.method_60655("minecraft","shulker_box"));
    var diamond=class_7923.field_41178.method_10223(class_2960.method_60655("minecraft","diamond"));
    var stack=new class_1799(item);
    var contents=java.util.List.of(new class_1799(diamond,5));
    stack.method_57379(class_9334.field_49622,class_9288.method_57493(contents));
    int nativeCount=0;for(var value:stack.method_57824(class_9334.field_49622).method_59714()) nativeCount+=value.method_7947();
    System.out.println("SHULKER_FIXTURE nativeContainerCount=" + nativeCount);
    com.misterpemodder.shulkerboxtooltip.impl.PluginManager.loadProviders();
    var context=PreviewContext.of(stack);
    var provider=ShulkerBoxTooltipApi.getPreviewProviderForStack(stack);
    System.out.println("SHULKER_PROVIDER class=" + (provider==null?"null":provider.getClass().getName()));
    if (provider == null) { System.out.println("SHULKER_CONTRACT_FAIL noProvider");return; }
    var inv=provider.getInventory(context);
    int count=inv.stream().filter(s -> s.method_31574(diamond)).mapToInt(class_1799::method_7947).sum();
    System.out.println("SHULKER_CONTRACT_RESULT diamondCount="+count+" expected=5 shouldDisplay="+provider.shouldDisplay(context));
   } catch (Throwable e) {System.out.println("SHULKER_CONTRACT_FAIL "+e);e.printStackTrace();}
  });
 }
}''',
'TreeContractProbe':'''package probe;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.*;
public class TreeContractProbe implements ModInitializer {
 class_3222 player;int ticks=0;boolean failed=false;
 public void onInitialize() {
  ServerPlayConnectionEvents.JOIN.register((h,s,v) -> {player=h.method_32311();System.out.println("TREE_PLAYER_JOINED");});
  ServerTickEvents.END_SERVER_TICK.register(server -> {
   if(player==null||failed)return;
   ticks++;var w=player.method_51469();
   try {
    if(ticks==40){
     var stone=class_7923.field_41175.method_10223(class_2960.method_60655("minecraft","stone")).method_9564();
     var air=class_7923.field_41175.method_10223(class_2960.method_60655("minecraft","air")).method_9564();
     var log=class_7923.field_41175.method_10223(class_2960.method_60655("minecraft","oak_log")).method_9564();
     var leaves=class_7923.field_41175.method_10223(class_2960.method_60655("minecraft","oak_leaves")).method_9564();
     for(int x=28;x<=36;x++)for(int z=28;z<=36;z++){
      w.method_8652(new class_2338(x,109,z),stone,3);
      for(int y=110;y<=116;y++)w.method_8652(new class_2338(x,y,z),air,3);
     }
     for(int x=31;x<=33;x++)for(int z=31;z<=33;z++)w.method_8652(new class_2338(x,114,z),leaves,3);
     for(int y=110;y<=113;y++)w.method_8652(new class_2338(32,y,32),log,3);
     player.method_7336(class_1934.field_9215);
     player.method_5814(30,110,32);
     var axe=class_7923.field_41178.method_10223(class_2960.method_60655("minecraft","diamond_axe"));
     player.method_6122(class_1268.field_5808,new class_1799(axe));
     System.out.println("TREE_FIXTURE logs=4 axe="+player.method_6047());
    }
    if(ticks==60){
     boolean broke=player.field_13974.method_14266(new class_2338(32,110,32));
     System.out.println("TREE_BREAK_RESULT broke="+broke);
    }
    if(ticks==100){
     int logs=0;
     for(int y=110;y<=113;y++)if(w.method_8320(new class_2338(32,y,32)).toString().contains("oak_log"))logs++;
     System.out.println("TREE_CONTRACT_RESULT remainingLogs="+logs+" expected=0");
    }
   }catch(Throwable e){failed=true;System.out.println("TREE_CONTRACT_FAIL "+e);e.printStackTrace();}
  });
 }
}'''}
cp=[B/'test-repo/work/cb/data/jars/client-1.21.1-intermediary.jar',T/'fabric-loader-0.19.5.jar',* (B/'probes/deps').glob('*.jar'),* (R/'patched/shulkerboxtooltip').glob('*.jar'),* (B/'test-repo/work/instances/fabric-1.21.1-server/libraries/com/mojang').rglob('*.jar')]
for name,source in sources.items():
    d=D/name;d.mkdir(exist_ok=True);src=d/(name+'.java');src.write_text(source,encoding='utf-8')
    result=subprocess.run([str(J/'javac.exe'),'-encoding','UTF-8','-proc:none','--release','21','-cp',';'.join(map(str,cp)),'-d',str(d),str(src)],capture_output=True,text=True)
    (d/'compile.log').write_text(result.stdout+result.stderr)
    if result.returncode:print(result.stderr);continue
    client=name.startswith('Shulker')
    with zipfile.ZipFile(D/(name+'.jar'),'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('fabric.mod.json',json.dumps({'schemaVersion':1,'id':name.lower(),'version':'1.0','environment':'client' if client else '*','entrypoints':{'client' if client else 'main':['probe.'+name]}}))
        for f in d.rglob('*.class'):z.write(f,f.relative_to(d).as_posix())
    print('compiled',name)
