from pathlib import Path
import subprocess, json, os, hashlib
B=Path(__file__).resolve().parent
R=B/'expansion'; P=B/'expansion-repo'; T=B/'test-repo/work/target'
env=os.environ.copy();env['JAVA_HOME']=str(B/'jdk21')
env['JAVA_OPTS']='-Djava.io.tmpdir='+str(R/'tmp')
samples=json.loads((R/'conversion-results.json').read_text())
for s in samples:
    out=R/'patched'/s['slug'];out.mkdir(parents=True,exist_ok=True)
    jar=out/Path(s['convertedFiles'][0]).name
    args=[str(P/'java/build/install/mcbridge1201/bin/mcbridge1201.bat'),'patch',
          '--in',s['convertedFiles'][0],'--out',str(jar),'--rules',str(P/'rules/fabric-1.21.1/container.json'),
          '--client-jar',str(T/'client-1.21.1.jar'),'--mappings',str(T/'intermediary-1.21.1-v2.jar'),
          '--bridge-dir',str(B/'test-repo/work/bridges')]
    with (out/'patch.log').open('w',encoding='utf-8') as f:
        p=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
    s['patchExitCode']=p.returncode
    if p.returncode==0:
        s['patchedFile']=str(jar);s['patchedSha256']=hashlib.sha256(jar.read_bytes()).hexdigest()
    print(s['slug'],p.returncode,flush=True)
(R/'patch-results.json').write_text(json.dumps(samples,indent=2),encoding='utf-8')
