import sys,json
from expand_runtime import R,SAMPLES,run
deps=json.loads((R/'dependencies.json').read_text())
if sys.argv[1]=='server':
    native=next(d for d in deps if d['slug']=='clumps')
    result=[run({'slug':'clumps-native-positive','patchedFile':native['path']},'server','native-control')]
else:
    result=[run({'slug':'control','patchedFile':'none'},'client')]
    cloth=next(d for d in deps if d['slug']=='cloth-config')
    shulker=next(d for d in SAMPLES if d['slug']=='shulkerboxtooltip')
    result.append(run(shulker,'client','native-cloth',cloth['path']))
(R/('followup-'+sys.argv[1]+'-results.json')).write_text(json.dumps(result,indent=2),encoding='utf-8')
