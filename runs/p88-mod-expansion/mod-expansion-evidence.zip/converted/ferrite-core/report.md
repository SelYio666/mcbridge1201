# CenturyBridge conversion report (1.20.1 -> 1.21.1, 7 segments)

## ferritecore -- ok_degraded_partial
- unsigned: entry digests dropped (conversion invalidates them)
- minecraft dep -> 1.21.1
- output: ferritecore-6.0.1-fabric+1.21.1.jar
- stripped mixin: FastMapStateHolderMixin [load-bearing! may be unstable] -- L2@1.20.4->1.20.5: shadow-field field_24738
- stripped mixin: ModelResourceLocationMixin -- L3@1.20.6->1.21: shadow-field field_5406
- tombstoned (lazy-fail) @1.20.2->1.20.3: net/minecraft/class_156.method_655()Lit/unimi/dsi/fastutil/Hash$Strategy;
