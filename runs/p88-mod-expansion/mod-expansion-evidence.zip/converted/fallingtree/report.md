# CenturyBridge conversion report (1.20.1 -> 1.21.1, 7 segments)

## fallingtree -- ok_partial
- unsigned: entry digests dropped (conversion invalidates them)
- output: FallingTree-1.20.1-4.3.4+1.21.1.jar
- L2 method @1.20.4->1.20.5: class_1799.method_7956
- L2 method @1.20.6->1.21: class_1890.method_8225
- L3 class @1.20.4->1.20.5: net/minecraft/class_1886
- L3 constructor: class_1887.<init>(Lnet/minecraft/class_1887$class_1888;Lnet/minecraft/class_1886;[Lnet/minecraft/class_1304;)V
- L3 constructor: class_2960.<init>(Ljava/lang/String;)V
- L3 field @1.20.4->1.20.5: class_1886.field_9082
- L3 field @1.20.4->1.20.5: class_1887$class_1888.field_9087
- L3 field @1.20.6->1.21: class_7923.field_41176
- tombstoned (lazy-fail) @1.20.4->1.20.5: net/minecraft/class_1792.method_7865(Lnet/minecraft/class_1799;Lnet/minecraft/class_2680;)F
- tombstoned (lazy-fail) @1.20.4->1.20.5: net/minecraft/class_1890.method_8222(Lnet/minecraft/class_1799;)Ljava/util/Map;
- tombstoned (lazy-fail) @1.20.6->1.21: net/minecraft/class_1887.method_8180(Lnet/minecraft/class_1887;)Z
