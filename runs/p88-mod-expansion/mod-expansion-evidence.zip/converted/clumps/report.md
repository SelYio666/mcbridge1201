# CenturyBridge conversion report (1.20.1 -> 1.21.1, 7 segments)

## clumps -- ok_degraded
- minecraft dep -> 1.21.1
- output: Clumps-fabric-1.20.1-12.0.0.4+1.21.1.jar
- stripped mixin: MixinExperienceOrb [load-bearing! may be unstable] -- L2@1.20.6->1.21: shadow method_35051; L3@1.20.6->1.21: shadow method_5917; L3@1.20.6->1.21: shadow method_5922; L2@1.20.6->1.21: inject-target method_35051; L3@1.20.6->1.21: at method_24365; L2@1.20.6->1.21: inject-target method_35051; L3@1.20.6->1.21: at method_24365
