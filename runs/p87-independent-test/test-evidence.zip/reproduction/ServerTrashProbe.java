package independent;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.blay09.mods.trashslot.TrashHelper;
import net.minecraft.*;
public class ServerTrashProbe implements ModInitializer {
 private class_3222 player; private int ticks;
 public void onInitialize() {
  ServerPlayConnectionEvents.JOIN.register((handler,sender,server)->player=handler.method_32311());
  ServerTickEvents.END_SERVER_TICK.register(server->{
   if(player==null)return; ticks++;
   if(ticks==20) { player.method_31548().method_5448(); player.method_7270(new class_1799(class_1802.field_8477,5)); }
   if(ticks%20==0) System.out.println("TRASH_SERVER tick="+ticks+" trash="+TrashHelper.getTrashItem(player).method_7947()+" carried="+player.field_7512.method_34255().method_7947());
  });
 }
}
