package independent;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.blay09.mods.trashslot.client.TrashSlotGuiHandler;
import net.blay09.mods.trashslot.config.TrashSlotConfig;
import net.minecraft.*;
public class ClientTrashProbe implements ClientModInitializer {
 private int ticks;
 public void onInitializeClient() {
  ClientTickEvents.END_CLIENT_TICK.register(client->{
   if(client.field_1724==null)return; ticks++;
   if(ticks==40) client.method_1507(new class_490(client.field_1724));
   var handler=client.field_1724.field_7512;
   var trash=TrashSlotGuiHandler.getTrashSlot();
   var provider=TrashSlotConfig.getDeletionProvider();
   if(ticks==80) {
    for(int i=0;i<handler.field_7761.size();i++) {
     var item=handler.method_7611(i).method_7677();
     if(item.method_7909()==class_1802.field_8477 && item.method_7947()==5) {
      client.field_1761.method_2906(handler.field_7763,i,0,class_1713.field_7790,client.field_1724);
      System.out.println("TRASH_PICKED slot="+i); break;
     }
    }
   }
   if(trash==null||provider==null)return;
   if(ticks==120||ticks==240) provider.deleteMouseItem(client.field_1724,handler.method_34255(),trash,false);
   if(ticks==180) provider.undeleteLast(client.field_1724,trash,false);
   if(ticks==300) provider.emptyTrashSlot(trash);
   String phase=ticks==160?"DELETED":ticks==220?"RETURNED":ticks==280?"REDELETED":ticks==340?"FINAL":null;
   if(phase!=null) System.out.println("TRASH_CLIENT_"+phase+" trash="+trash.method_7677().method_7947()+" carried="+handler.method_34255().method_7947());
  });
 }
}
