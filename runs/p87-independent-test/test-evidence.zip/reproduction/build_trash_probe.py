from pathlib import Path
import subprocess, json, zipfile
BASE=Path(__file__).resolve().parent
REPO=BASE/'test-repo'
SRC=BASE/'trash-probe-src'
SRC.mkdir(exist_ok=True)
(SRC/'ServerTrashProbe.java').write_text('''package independent;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.blay09.mods.trashslot.TrashHelper;
import net.minecraft.*;
public class ServerTrashProbe implements ModInitializer {
 private class_3222 player; private int ticks;
 public void onInitialize() {
  ServerPlayConnectionEvents.JOIN.register((handler,sender,server)->player=handler.method_32311());
  ServerTickEvents.END_SERVER_TICK.register(server->{
   if(player==null)return; ticks++;
   if(ticks==20) { player.method_31548().method_5448(); player.method_7270(new class_1799(class_1802.field_8477,5)); }
   if(ticks%20==0) System.out.println("TRASH_SERVER tick="+ticks+" trash="+TrashHelper.getTrashItem(player).method_7947()+" carried="+player.field_7512.method_34255().method_7947());
  });
 }
}
''',encoding='utf-8')
(SRC/'ClientTrashProbe.java').write_text('''package independent;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.blay09.mods.trashslot.client.TrashSlotGuiHandler;
import net.blay09.mods.trashslot.config.TrashSlotConfig;
import net.minecraft.*;
public class ClientTrashProbe implements ClientModInitializer {
 private int ticks;
 public void onInitializeClient() {
  ClientTickEvents.END_CLIENT_TICK.register(client->{
   if(client.field_1724==null)return; ticks++;
   if(ticks==40) client.method_1507(new class_490(client.field_1724));
   var handler=client.field_1724.field_7512;
   var trash=TrashSlotGuiHandler.getTrashSlot();
   var provider=TrashSlotConfig.getDeletionProvider();
   if(ticks==80) {
    for(int i=0;i<handler.field_7761.size();i++) {
     var item=handler.method_7611(i).method_7677();
     if(item.method_7909()==class_1802.field_8477 && item.method_7947()==5) {
      client.field_1761.method_2906(handler.field_7763,i,0,class_1713.field_7790,client.field_1724);
      System.out.println("TRASH_PICKED slot="+i); break;
     }
    }
   }
   if(trash==null||provider==null)return;
   if(ticks==120||ticks==240) provider.deleteMouseItem(client.field_1724,handler.method_34255(),trash,false);
   if(ticks==180) provider.undeleteLast(client.field_1724,trash,false);
   if(ticks==300) provider.emptyTrashSlot(trash);
   String phase=ticks==160?"DELETED":ticks==220?"RETURNED":ticks==280?"REDELETED":ticks==340?"FINAL":null;
   if(phase!=null) System.out.println("TRASH_CLIENT_"+phase+" trash="+trash.method_7677().method_7947()+" carried="+handler.method_34255().method_7947());
  });
 }
}
''',encoding='utf-8')
cp=';'.join(map(str,[REPO/'work/cb/data/jars/client-1.21.1-intermediary.jar',
 REPO/'work/target/fabric-loader-0.19.5.jar',*BASE.glob('probes/deps/*.jar'),
 *REPO.glob('work/instances/fabric-1.21.1-server/libraries/com/mojang/**/*.jar'),
 REPO/'work/instances/fabric-1.21.1-server/mods/trashslot-client-empty.jar',
 REPO/'work/instances/fabric-1.21.1-server/mods/balm-fabric-1.21.1.jar']))
CLS=SRC/'classes';CLS.mkdir(exist_ok=True)
subprocess.run([str(BASE/'jdk21/bin/javac.exe'),'--release','21','-encoding','UTF-8','-proc:none',
 '-cp',cp,'-d',str(CLS),*map(str,SRC.glob('*.java'))],check=True)
with zipfile.ZipFile(BASE/'probes/trashprobe.jar','w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('fabric.mod.json',json.dumps({'schemaVersion':1,'id':'independenttrashprobe','version':'1',
  'entrypoints':{'main':['independent.ServerTrashProbe'],'client':['independent.ClientTrashProbe']}}))
 for f in CLS.rglob('*.class'):z.write(f,f.relative_to(CLS).as_posix())
print('compiled trash probe')
