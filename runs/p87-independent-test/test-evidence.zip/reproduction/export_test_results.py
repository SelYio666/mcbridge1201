from pathlib import Path
import json, zipfile, hashlib, shutil, subprocess, datetime

BASE=Path(__file__).resolve().parent
ROOT=BASE.parent
OUT=ROOT/'outputs'
OUT.mkdir(exist_ok=True)
REPO=BASE/'test-repo'
COMMIT='d9e88a1610fee06e09a10be503185adde206ddf6'
result={
 'testedCommit':COMMIT,
 'sourceTree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=REPO,text=True).strip(),
 'trackedFilesUnchanged':not subprocess.check_output(['git','status','--porcelain'],cwd=REPO,text=True).strip(),
 'sourceAcquisition':'Local Git clone at the exact commit verified against the public GitHub commit and tree. GitHub clone/archive attempts were slow; runtime dependencies and intermediate input were copied from the existing local development directory.',
 'environment':{'minecraft':'1.21.1','loader':'0.19.5','fabricApi':'0.102.0+1.21.1','balm':'21.0.66','jdk':'Zulu 21.0.12.1','gradle':'9.8.1'},
 'runtimeArtifacts':{},
}
for name in ['ironchests-rebuilt.jar','lithium-final.jar','trashslot-client-empty.jar','balm-fabric-1.21.1.jar','fabric-api-0.102.0+1.21.1.jar']:
 p=REPO/'work/instances/fabric-1.21.1-server/mods'/name
 result['runtimeArtifacts'][name]=hashlib.sha256(p.read_bytes()).hexdigest()
for key,rel in [('container','runtime/container/verdict.json'),('chunk','runtime/chunk/verdict.json'),
 ('multiplayer','runtime/multiplayer-platform/verdict.json'),('tps','runtime/tps/verdict.json'),
 ('trash','runtime/trash-network/verdict.json'),('negativeControls','controls/results.json'),
 ('falseMarkers','controls/false-marker-verdict.json')]:
 p=BASE/rel
 result[key]=json.loads(p.read_text(encoding='utf-8'))
result['evidenceVerifier']=json.loads((BASE/'verify-evidence.json').read_text(encoding='utf-16'))
(OUT/'test-results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')

files={}
for directory in ['runtime','controls']:
 for p in (BASE/directory).rglob('*'):
  if p.is_file() and p.suffix.lower() in ['.log','.json','.java']:
   files['logs/'+p.relative_to(BASE).as_posix()]=p
for name in ['build-test4.log','rebuild-ironchests.log','raw-patch.log','clean-repro.log','corpus-hash-check.json','asset-setup.json']:
 files['logs/'+name]=BASE/name
for p in (REPO/'java/build/test-results/test').glob('TEST-*.xml'):
 files['unit-test-results/'+p.name]=p
for name in ['prepare_test_assets.py','compile_runtime_probes.py','check_test_controls.py',
 'run_multiplayer_test.py','run_tps_test.py','build_trash_probe.py','export_test_results.py']:
 files['reproduction/'+name]=BASE/name
for p in (BASE/'trash-probe-src').glob('*.java'):
 files['reproduction/'+p.name]=p
files['reproduction/DedicatedSyncProbe-platform.java']=BASE/'probes/DedicatedSyncProbe.java'
files['test-results.json']=OUT/'test-results.json'
checksums=[]
with zipfile.ZipFile(OUT/'test-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,path in sorted(files.items()):
  if not path.exists():continue
  data=path.read_bytes()
  checksums.append(hashlib.sha256(data).hexdigest()+'  '+name)
  z.writestr(name,data)
 z.writestr('SHA256SUMS.txt','\n'.join(checksums)+'\n')
print('exported',len(checksums),'evidence files')
print('all runtime:',{k:result[k].get('passed') for k in ['container','chunk','multiplayer','tps','trash']})
