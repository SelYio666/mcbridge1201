from pathlib import Path
import subprocess, shutil, socket, time, json, re
BASE=Path(__file__).resolve().parent
REPO=BASE/'test-repo'
SOURCE=BASE/'raw-input-server'
INST=BASE/'tps-server'
OUT=BASE/'runtime/tps'
OUT.mkdir(parents=True,exist_ok=True)
INST.mkdir(exist_ok=True)
for name in ['libraries','versions','.fabric']:
    shutil.copytree(SOURCE/name,INST/name,dirs_exist_ok=True)
for name in ['fabric-server-launch.jar','eula.txt']:
    shutil.copy2(SOURCE/name,INST/name)
(INST/'mods').mkdir(exist_ok=True)
(INST/'tmp').mkdir(exist_ok=True)
for src in [REPO/'work/target/fabric-api-0.102.0+1.21.1.jar',
            REPO/'work/instances/fabric-1.21.1-server/mods/lithium-final.jar',
            BASE/'probes/tpsprobe.jar']:
    shutil.copy2(src,INST/'mods'/src.name)
with socket.socket() as s:
    s.bind(('127.0.0.1',0));port=s.getsockname()[1]
(INST/'server.properties').write_text(f'server-ip=127.0.0.1\nserver-port={port}\nonline-mode=false\n'
    'view-distance=5\nsimulation-distance=5\nlevel-seed=785238\ngenerate-structures=false\n',encoding='utf-8')
logpath=OUT/'server.log'
with logpath.open('w',encoding='utf-8') as log:
    p=subprocess.Popen([str(BASE/'jdk21/bin/java.exe'),'-Xmx2G','-Dfile.encoding=UTF-8',
        f'-Djava.io.tmpdir={INST/"tmp"}','-jar','fabric-server-launch.jar','nogui'],
        cwd=INST,stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT,text=True,encoding='utf-8',
        creationflags=subprocess.CREATE_NO_WINDOW)
    try:
        deadline=time.monotonic()+150
        while time.monotonic()<deadline and p.poll() is None:
            if 'TPS_AVG' in logpath.read_text(encoding='utf-8',errors='replace'):break
            time.sleep(.5)
        if p.poll() is None:
            p.stdin.write('stop\n');p.stdin.flush();p.wait(timeout=30)
    finally:
        if p.poll() is None:p.kill();p.wait()
data=logpath.read_text(encoding='utf-8',errors='replace')
starts=re.findall(r'TPS_START loaded=(\d+)/289',data)
samples=re.findall(r'TPS_AVG tps=([\d.]+) ticks=(\d+) seconds=([\d.]+)',data)
result={'exitCode':p.returncode,'loaded':int(starts[-1]) if starts else 0,'samples':samples,
        'passed':p.returncode==0 and bool(samples) and bool(starts) and starts[-1]=='289',
        'scope':'one 1200-tick idle sample; no players, no mob-AI or redstone assertions'}
(OUT/'verdict.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
