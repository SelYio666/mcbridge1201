from pathlib import Path
import subprocess, json, hashlib, os
BASE=Path(__file__).resolve().parent
REPO=BASE/'test-repo'
OUT=BASE/'controls'
OUT.mkdir(exist_ok=True)
JAVA=BASE/'jdk21/bin'
fake=OUT/'crash-server'
fake.mkdir(exist_ok=True)
source=fake/'CrashAfterDone.java'
source.write_text('''import java.io.*;
public class CrashAfterDone {
 public static void main(String[] args) throws Exception {
  System.out.println("Done (0.001s)! For help, type help");
  new BufferedReader(new InputStreamReader(System.in)).readLine();
  System.err.println("CONTROL: simulated post-boot JVM failure");
  System.exit(7);
 }
}
''',encoding='utf-8')
subprocess.run([str(JAVA/'javac.exe'),str(source)],check=True)
subprocess.run([str(JAVA/'jar.exe'),'--create','--file',str(fake/'fabric-server-launch.jar'),
                '--main-class','CrashAfterDone','-C',str(fake),'CrashAfterDone.class'],check=True)
r=subprocess.run([os.sys.executable,str(REPO/'tools/run_server.py'),
    '--instance',str(fake),'--log',str(OUT/'crash-server.log'),'--java',str(JAVA/'java.exe')],
    capture_output=True,text=True,encoding='utf-8')
(OUT/'crash-server-result.json').write_text(r.stdout,encoding='utf-8')
d=json.loads(r.stdout)
result={'run_server_crash_control':{'scriptExitCode':r.returncode,
    'jvmExitCode':d['exitCode'],'doneSeen':d['doneSeen'],
    'bugReproduced':r.returncode==0 and d['exitCode']==7}}

tracked=set(subprocess.check_output(['git','ls-files'],cwd=REPO,text=True).splitlines())
matched=[]; mismatches=[]; unavailable=[]; newline_only=[]
for line in (REPO/'runs/SHA256SUMS.txt').read_text().splitlines():
    if '  ' not in line: continue
    expected,rel=line.split('  ',1)
    if rel not in tracked or expected.strip()=='MISSING': continue
    p=REPO/rel
    if not p.exists(): unavailable.append(rel); continue
    raw=p.read_bytes()
    actual=hashlib.sha256(raw).hexdigest()
    if actual==expected: matched.append(rel)
    elif hashlib.sha256(raw.replace(b'\r\n',b'\n')).hexdigest()==expected:
        newline_only.append(rel)
    else: mismatches.append(rel)
result['tracked_evidence_hashes']={'matched':len(matched),'newline_only':len(newline_only),
    'mismatches':mismatches,'missing':unavailable}
(OUT/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
