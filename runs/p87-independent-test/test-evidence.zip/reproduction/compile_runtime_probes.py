from pathlib import Path
import zipfile, subprocess, json
BASE=Path(__file__).resolve().parent
REPO=BASE/'test-repo'
JAVA=BASE/'jdk21/bin'
OUT=BASE/'probes'
DEPS=OUT/'deps'
DEPS.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(REPO/'work/target/fabric-api-0.102.0+1.21.1.jar') as z:
    for n in z.namelist():
        if n.startswith('META-INF/jars/') and n.endswith('.jar'):
            (DEPS/Path(n).name).write_bytes(z.read(n))
cp=';'.join(map(str,[REPO/'work/cb/data/jars/client-1.21.1-intermediary.jar',
                  REPO/'work/target/fabric-loader-0.19.5.jar',*DEPS.glob('*.jar'),
                  *REPO.glob('work/instances/fabric-1.21.1-server/libraries/com/mojang/**/*.jar')]))
for kind,source,entry,env in [
    ('dedprobe','p80-two-client-clean/DedicatedSyncProbe.java','probe.DedicatedSyncProbe','server'),
    ('lansyncprobe','p80-two-client-clean/LanSyncProbe.java','probe.LanSyncProbe','client'),
    ('tpsprobe','p84-lithium-tps/TpsProbe.java','probe.TpsProbe','server')]:
    cls=OUT/kind
    cls.mkdir(exist_ok=True)
    source_path=REPO/'runs'/source
    if kind=='dedprobe':
        source_path=OUT/'DedicatedSyncProbe.java'
        original=(REPO/'runs'/source).read_text(encoding='utf-8')
        original=original.replace('int x = (int) Math.floor(host.method_23317()) + 2;', 'int x = 32;')
        original=original.replace('int y = (int) Math.floor(host.method_23318());', 'int y = 110;')
        original=original.replace('int z = (int) Math.floor(host.method_23319());', 'int z = 32;')
        original=original.replace('chestPos = new class_2338(x, y, z);', '''chestPos = new class_2338(x, y, z);
                var world = host.method_51469();
                var stone = class_7923.field_41175.method_10223(class_2960.method_60655("minecraft", "stone"));
                var air = class_7923.field_41175.method_10223(class_2960.method_60655("minecraft", "air"));
                for (int dx = -6; dx <= 6; dx++) for (int dz = -6; dz <= 6; dz++) {
                    world.method_8652(new class_2338(x+dx, y-1, z+dz), stone.method_9564(), 3);
                    for (int dy = 0; dy < 4; dy++)
                        world.method_8652(new class_2338(x+dx, y+dy, z+dz), air.method_9564(), 3);
                }''')
        source_path.write_text(original,encoding='utf-8')
    subprocess.run([str(JAVA/'javac.exe'),'-encoding','UTF-8','--release','21','-proc:none',
                    '-cp',cp,'-d',str(cls),str(source_path)],check=True)
    entries={'main':[entry]}
    if kind=='lansyncprobe': entries['client']=[entry]
    metadata={'schemaVersion':1,'id':kind,'version':'1.0.0','environment':env,
              'entrypoints':entries,'depends':{'fabricloader':'>=0.16.0','minecraft':'1.21.1'}}
    with zipfile.ZipFile(OUT/f'{kind}.jar','w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('fabric.mod.json',json.dumps(metadata))
        for f in cls.rglob('*.class'): z.write(f,f.relative_to(cls).as_posix())
    print('compiled',kind)
