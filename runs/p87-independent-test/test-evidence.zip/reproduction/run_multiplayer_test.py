from pathlib import Path
import subprocess, json, os, time, shutil, threading, re, uuid, sys

BASE=Path(__file__).resolve().parent
REPO=BASE/'test-repo'
INST=REPO/'work/instances/fabric-1.21.1-server'
OUT=BASE/'runtime'/(sys.argv[1] if len(sys.argv)>1 else 'multiplayer')
TRASH=OUT.name.startswith('trash')
USERS=['HostA'] if TRASH else ['HostA','GuestB']
PROBE='trashprobe' if TRASH else 'dedprobe'
OUT.mkdir(parents=True,exist_ok=True)
JAVA=BASE/'jdk21/bin/java.exe'
MC=Path(r'D:\我的世界\.minecraft')
VERSION=MC/'versions/fabric-loader-0.19.5-1.21.1'
VANILLA=MC/'versions/1.21.1'
PORT=int(re.search(r'server-port=(\d+)',(INST/'server.properties').read_text()).group(1))

def allowed(lib):
    rules=lib.get('rules')
    if not rules:return True
    result=False
    for rule in rules:
        os_name=rule.get('os',{}).get('name')
        if os_name is None or os_name=='windows': result=rule['action']=='allow'
    return result

base=json.loads((VANILLA/'1.21.1.json').read_text(encoding='utf-8'))
fabric=json.loads((VERSION/'fabric-loader-0.19.5-1.21.1.json').read_text(encoding='utf-8'))
cp=[]
for lib in base['libraries']:
    if not allowed(lib):continue
    art=lib.get('downloads',{}).get('artifact',{}).get('path')
    if art:cp.append(MC/'libraries'/art)
for lib in fabric['libraries']:
    parts=lib['name'].split(':'); group,artifact,version=parts[:3]
    filename=f'{artifact}-{version}'+(':'+parts[3] if len(parts)>3 else '')+'.jar'
    cp.append(MC/'libraries'/group.replace('.','/')/artifact/version/filename)
cp.append(VANILLA/'1.21.1.jar')
missing=[str(p) for p in cp if not p.exists()]
if missing:raise RuntimeError('Missing libraries: '+str(missing))

processes=[]; handles=[]
def spawn(args,cwd,log):
    handle=open(log,'w',encoding='utf-8'); handles.append(handle)
    proc=subprocess.Popen(list(map(str,args)),cwd=cwd,stdin=subprocess.PIPE,
        stdout=handle,stderr=subprocess.STDOUT,text=True,encoding='utf-8',
        creationflags=subprocess.CREATE_NO_WINDOW)
    processes.append(proc)
    return proc

def readlog(name):
    path=OUT/name
    return path.read_text(encoding='utf-8',errors='replace') if path.exists() else ''

def wait_for(predicate,timeout):
    end=time.monotonic()+timeout
    while time.monotonic()<end:
        if predicate():return True
        time.sleep(.5)
    return False

result={}
try:
    shutil.copy2(BASE/'probes'/f'{PROBE}.jar',INST/'mods'/f'{PROBE}.jar')
    server=spawn([JAVA,'-Xmx2G','-Dfile.encoding=UTF-8',f'-Djava.io.tmpdir={INST/"tmp"}',
                  '-jar','fabric-server-launch.jar','nogui'],INST,OUT/'server.log')
    if not wait_for(lambda:'Done (' in readlog('server.log') or server.poll() is not None,90):
        raise RuntimeError('Server boot timeout')
    if server.poll() is not None: raise RuntimeError('Server exited before clients')
    for user in USERS:
        game=OUT/user
        (game/'mods').mkdir(parents=True,exist_ok=True)
        (game/'tmp').mkdir(exist_ok=True)
        for mod in (INST/'mods').glob('*.jar'):
            if mod.name!='dedprobe.jar':shutil.copy2(mod,game/'mods'/mod.name)
        if not TRASH:shutil.copy2(BASE/'probes/lansyncprobe.jar',game/'mods/lansyncprobe.jar')
        (game/'options.txt').write_text('renderDistance:3\nsimulationDistance:3\nmaxFps:60\n'
            'pauseOnLostFocus:false\nlang:en_us\nsoundCategory_master:0.0\n'
            'graphicsMode:0\nguiScale:2\nenableVsync:false\n',encoding='utf-8')
        args=[JAVA,'-Xmx1536M','-Xms256M',f'-Djava.io.tmpdir={game/"tmp"}',
            '-Dfile.encoding=UTF-8','-Dfabric.development=false',
            '-cp',';'.join(map(str,cp)),fabric['mainClass'],
            '--username',user,'--version','fabric-loader-0.19.5-1.21.1',
            '--gameDir',game,'--assetsDir',MC/'assets','--assetIndex','17',
            '--uuid',str(uuid.uuid3(uuid.NAMESPACE_DNS,'OfflinePlayer:'+user)).replace('-',''),
            '--accessToken','0','--clientId','0','--xuid','0','--versionType','release',
            '--width','854','--height','480','--quickPlayMultiplayer',f'127.0.0.1:{PORT}']
        spawn(args,game,OUT/f'{user}.log')
    signaled=wait_for(lambda: server.poll() is not None or
        (TRASH and 'TRASH_CLIENT_FINAL' in readlog('HostA.log')) or
        (not TRASH and 'DED_TOTAL' in readlog('server.log') and
        all('LAN_POST' in readlog(f'{u}.log') for u in USERS)),180)
    finished=signaled and ('TRASH_CLIENT_FINAL' in readlog('HostA.log') if TRASH else 'DED_TOTAL' in readlog('server.log'))
    serverlog=readlog('server.log')
    clients={u:readlog(f'{u}.log') for u in USERS}
    total=re.findall(r'DED_TOTAL chest=(\d+) \S+ hostSlot54=(\d+) \S+ guestSlot54=(\d+) \S+',serverlog)
    takes={u:re.findall(r'LAN_TAKE player=\w+ time=(\d+).*',log) for u,log in clients.items()}
    posts={u:re.findall(r'LAN_POST player=.*',log) for u,log in clients.items()}
    counts=list(map(int,total[-1])) if total else []
    result={'completed':finished,'serverTotals':counts,'takeTicks':takes,'clientPost':posts,
        'serverAlive':server.poll() is None,'clientAlive':[p.poll() is None for p in processes[1:]],
        'conserved':bool(counts) and sum(counts)==7,
        'sameWorldTick':bool(all(takes.values())) and len({v[-1] for v in takes.values()})==1}
    result['passed']=all([result['completed'],result['conserved'],result['sameWorldTick'],
        result['serverAlive'],all(result['clientAlive'])])
    if TRASH:
        result['clientStates']=re.findall(r'TRASH_CLIENT_\w+ trash=\d+ carried=\d+',clients['HostA'])
        result['serverStates']=re.findall(r'TRASH_SERVER tick=\d+ trash=\d+ carried=\d+',serverlog)
        result['passed']=all(s in clients['HostA'] for s in [
            'TRASH_CLIENT_DELETED trash=5 carried=0','TRASH_CLIENT_RETURNED trash=0 carried=5',
            'TRASH_CLIENT_REDELETED trash=5 carried=0','TRASH_CLIENT_FINAL trash=0 carried=0']) and all(
            s in serverlog for s in ['trash=5 carried=0','trash=0 carried=5']) and result['serverAlive']
finally:
    for p in processes[1:]:
        if p.poll() is None:p.terminate()
    if processes and processes[0].poll() is None:
        try:
            processes[0].stdin.write('stop\n');processes[0].stdin.flush()
            processes[0].wait(timeout=35)
        except Exception:processes[0].kill()
    for p in processes:
        try:p.wait(timeout=10)
        except subprocess.TimeoutExpired:p.kill()
    for h in handles:h.close()
    result['processExitCodes']=[p.poll() for p in processes]
    (OUT/'verdict.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    (INST/'mods'/f'{PROBE}.jar').unlink(missing_ok=True)
print(json.dumps(result,indent=2))
