from pathlib import Path
import shutil, json, hashlib, socket

BASE = Path(__file__).resolve().parent
SRC = Path(r'C:\Users\27682\Documents\新建文件夹\mcbridge1201')
DST = BASE/'test-repo'
records=[]
def copy(rel):
    src, dst = SRC/rel, DST/rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    if src.is_dir():
        shutil.copytree(src, dst, dirs_exist_ok=True)
    else:
        shutil.copy2(src,dst)
    records.append(str(rel))

for rel in ['work/lib','work/target','work/corpus',
            'work/cb/data/jars/client-1.21.1-intermediary.jar',
            'work/client/ironchests-modelbridge2.jar']:
    copy(rel)
inst=Path('work/instances/fabric-1.21.1-server')
for rel in ['libraries','.fabric','versions','fabric-server-launch.jar','eula.txt']:
    copy(inst/rel)
server=DST/inst
mods=server/'mods'
mods.mkdir(exist_ok=True)
for name in ['fabric-api-0.102.0+1.21.1.jar','balm-fabric-1.21.1.jar']:
    shutil.copy2(SRC/'work/instances/fabric-1.21.1-server-all-three/mods'/name,mods/name)
for name in ['lithium-final.jar','trashslot-client-empty.jar']:
    shutil.copy2(SRC/'work/client'/name,mods/name)
with socket.socket() as sock:
    sock.bind(('127.0.0.1',0))
    port=sock.getsockname()[1]
(server/'server.properties').write_text(
    f'server-ip=127.0.0.1\nserver-port={port}\nonline-mode=false\n'
    'level-name=independent-test-world\nlevel-seed=785238\n'
    'generate-structures=false\nview-distance=5\nsimulation-distance=5\n'
    'spawn-protection=0\nmotd=Independent local test\n',encoding='utf-8')
(BASE/'asset-setup.json').write_text(json.dumps({'copied':records,'port':port,
    'runtimeModHashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in mods.glob('*.jar')}},indent=2),encoding='utf-8')
print('copied',len(records),'groups; port',port)
